# Rackform — konfigurator regałów paletowych

Statyczny konfigurator do wstępnego planowania regałów paletowych. Działa bez serwera i zapisuje bieżący projekt w pamięci przeglądarki.

## Funkcje

- wymiary palety, liczba poziomów oraz osobne wysokości światła i ładunku na każdym poziomie; poziom 1 jest na posadzce;
- automatyczny dobór głębokości i wysokości ramy z możliwością ręcznej zmiany;
- dobór trawersu dla 1–4 palet w każdej sekcji;
- zestawy 1000 / 1900 / 2700 / 3600 mm (standard) i 1000 / 1900 / 2850 / 3800 mm (NFPA 13);
- dowolna liczba sekcji oraz rzędów pojedynczych i podwójnych;
- brak wypełnienia lub panel siatkowy, krata, poprzeczki albo płyta wiórowa; ochrona słupów: brak, odbojnica lub tuba z tworzywa zakładana na słup; zabezpieczenie tyłu: brak, wygrodzenie siatkowe pleców albo backstopy;
- orientacyjny korytarz dla wózka czołowego, reach trucka i VNA;
- rysunek wybranego rzędu i wynik gotowy do wydruku lub zapisania jako PDF;
- plan wszystkich regałów z korytarzami pracy oraz interaktywny model 3D z obrotem, przybliżeniem i powiększeniem na cały ekran;
- dodawanie sekcji przez przeciągnięcie uchwytu `+` na planie lub kliknięcie półprzezroczystego `+` przy regale w widoku 3D (uchwyt na planie działa też po kliknięciu i z klawiatury).

## Założenia obliczeń

Luz boczny i między paletami wynosi orientacyjnie 75 mm w trybie standardowym oraz 100 mm w trybie NFPA 13. Dobierany jest pierwszy trawers z odpowiedniego zestawu, który pomieści wskazaną liczbę palet i wymagane luzy. Wysokość trawersu wynosi 150 mm. Do widoku przyjęto słup 100 mm, a długość rzędu jest pokazywana jako przedział dla profili 85–120 mm.

Domyślna głębokość ramy jest o 100 mm mniejsza niż głębokość ładunku; można ją zmienić ręcznie i przywrócić dobór automatyczny. Gdy głębokość ramy jest równa lub większa od głębokości ładunku, konfigurator wskazuje konieczność odpowiedniego wypełnienia poziomów, np. poprzeczek lub kraty. Wysokość ramy jest dobierana co 250 mm i można ją zwiększyć ręcznie. Minimalna wysokość mieści poziomy, ładunki i zapas 300 mm ponad światłem najwyższego poziomu.

W podwójnym rzędzie minimalna przerwa między ładunkami wynosi 100 mm, a między ramami 200 mm. NFPA 13 lub backstopy zwiększają oba minima o 50 mm, naliczane tylko raz, również gdy wybrane są oba ustawienia. Jeśli ręcznie zmieniona głębokość ramy tego wymaga, przerwa między ramami jest powiększana, aby zachować odstęp między ładunkami. Wynik i plan pokazują oba wymiary.

Orientacyjne szerokości korytarza: wózek czołowy 3500 mm, reach truck 2800 mm, VNA 1800 mm. Docelowy wymiar zależy od konkretnego modelu wózka i ładunku. Konfigurator nie oblicza nośności ani zgodności z przepisami; wymaga to projektu technicznego. Wariant NFPA 13 oznacza odrębny zestaw długości i przyjęty luz, a nie potwierdzenie zgodności instalacji z NFPA 13.

Każdy poziom ma edytowalne światło i wysokość ładunku. Światło przyjęte do obliczeń wynosi co najmniej wysokość ładunku + 100 mm i jest zaokrąglane w górę do skoku 50 mm; gdy pole użytkownika jest mniejsze, pojawia się ostrzeżenie. Pierwsza paleta stoi na posadzce, a pierwsza belka jest nad nią, na wysokości światła poziomu 1. Każda kolejna belka znajduje się nad poprzednim poziomem o przyjęte światło; paleta stoi na górnej powierzchni belki o wysokości 150 mm. Wysokość ramy jest zaokrąglana w górę do 250 mm. Widok frontowy i 3D pokazują różnice między poziomami i wysokościami ładunków.

Plan umieszcza korytarz przed każdym rzędem, a także za ostatnim rzędem, jeśli jest podwójny. Pokazywana głębokość układu obejmuje te korytarze. Plan i widok 3D są poglądowe; korytarze oraz model wymagają doprecyzowania dla konkretnej hali i wózka.

Zabezpieczenie tyłu jest wspólne dla wszystkich regałów. Na pojedynczym rzędzie umieszczamy je przy tylnej krawędzi, a na podwójnym po obu stronach środkowego odstępu. Plan i widok 3D pokazują siatkę jako panel, a backstopy jako poziome ograniczniki przy poziomach składowania. Ich gabaryt i mocowanie wymagają osobnego doboru.

Odbojnica z tworzywa jest tubą zakładaną na słup od strony korytarza. Model 3D pokazuje jej ogólną formę bez odwzorowania konkretnego produktu lub jego parametrów.

Kolorystyka konstrukcji: słupy RAL 5010, belki RAL 1007, odbojnice RAL 1004, diagonale ramy ocynkowane (galva). Odcienie widoczne na ekranie są przybliżeniem, a ostateczny kolor należy porównać z fizycznym wzornikiem RAL. Diagonale są widoczne w modelu 3D, ponieważ znajdują się w płaszczyźnie ramy bocznej.

## Uruchomienie

Rozpakuj archiwum i otwórz `index.html` dwuklikiem. Konfigurator działa również przez serwer statyczny, np. `python3 -m http.server 4173` pod adresem `http://127.0.0.1:4173/`.

Testy obliczeń: `npm test`. Przebudowa lokalnego skryptu 3D: `npm ci && npm run build`. Zbudowany plik `src/scene3d.bundle.js` jest częścią strony i działa bez pobierania bibliotek z CDN.

Publikacja na GitHub Pages odbywa się przez `.github/workflows/pages.yml` po włączeniu źródła **GitHub Actions** w ustawieniach Pages repozytorium.
