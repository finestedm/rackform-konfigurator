(function (root) {
'use strict';

const NS = 'http://www.w3.org/2000/svg';
// Screen previews of the requested RAL finishes; physical swatches define the final colours.
const COLORS = Object.freeze({ post: '#00558b', beam: '#e8a900', guard: '#d9a500', guardLight: '#f2d46f', galva: '#a9b4b8' });
function element(name, attrs = {}, text) {
  const node = document.createElementNS(NS, name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
  if (text !== undefined) node.textContent = text;
  return node;
}
function add(svg, name, attrs, text) { const node = element(name, attrs, text); svg.append(node); return node; }
function path(points) { return points.map((point, index) => `${index ? 'L' : 'M'} ${point[0].toFixed(1)} ${point[1].toFixed(1)}`).join(' ') + ' Z'; }

function drawPlan(svg, config, result, selectedId, onSelect, onAddSection) {
  svg.replaceChildren();
  const x0 = 45, width = 485, aisleHeight = 59;
  const rowHeights = result.rows.map(row => row.type === 'double' ? 73 : 49);
  const height = 78 + result.aisles.length * aisleHeight + rowHeights.reduce((a, b) => a + b, 0) + 63;
  svg.setAttribute('viewBox', `0 0 620 ${height}`);
  svg.setAttribute('aria-label', `Plan ${result.rows.length} regałów i ${result.aisles.length} korytarzy pracy o szerokości ${result.aisle} mm`);
  const maxLength = Math.max(1, ...result.rows.map(row => row.nominalLength));
  add(svg, 'text', {x:x0,y:24,fill:'#49625f','font-size':13,'font-family':'DM Sans','font-weight':700}, 'RZUT Z GÓRY / WSZYSTKIE REGAŁY');
  add(svg, 'text', {x:575,y:24,'text-anchor':'end',fill:'#81938e','font-size':11,'font-family':'DM Sans'}, `${result.rows.length} ${result.rows.length===1?'RZĄD':result.rows.length<5?'RZĘDY':'RZĘDÓW'} · ${result.aisles.length} ${result.aisles.length===1?'KORYTARZ':result.aisles.length<5?'KORYTARZE':'KORYTARZY'}`);
  add(svg, 'line', {x1:x0,y1:49,x2:x0+width,y2:49,stroke:'#7b9690','stroke-width':1});
  add(svg, 'path', {d:`M ${x0} 44 v 10 M ${x0+width} 44 v 10`,stroke:'#7b9690','stroke-width':1,fill:'none'});
  add(svg, 'text', {x:x0+width/2,y:43,'text-anchor':'middle',fill:'#47625b','font-size':12,'font-family':'Space Grotesk','font-weight':700}, result.valid ? `DŁUGOŚĆ ZABUDOWY ${Math.round(result.longestMin)}–${Math.round(result.longestMax)} mm*` : 'DŁUGOŚĆ: BRAK DOBORU');

  let y = 68;
  const drawAisle = (aisle, index) => {
    add(svg, 'rect', {x:x0,y,width,height:aisleHeight,fill:'#e2eeeb',stroke:'#b9d1cb','stroke-width':1});
    add(svg, 'line', {x1:x0+18,y1:y+aisleHeight/2,x2:x0+width-18,y2:y+aisleHeight/2,stroke:'#75a99d','stroke-width':1.5,'stroke-dasharray':'8 6'});
    add(svg, 'path', {d:`M ${x0+width-19} ${y+aisleHeight/2} l -9 -5 v 10 Z`,fill:'#75a99d'});
    add(svg, 'text', {x:x0+width/2,y:y+aisleHeight/2-7,'text-anchor':'middle',fill:'#426f65','font-size':13,'font-family':'Space Grotesk','font-weight':700}, `KORYTARZ PRACY ${Math.round(result.aisle)} mm`);
    add(svg, 'text', {x:9,y:y+aisleHeight/2+4,fill:'#8ba8a0','font-size':12,'font-family':'DM Sans','font-weight':700}, `K${index+1}`);
    y += aisleHeight;
  };

  result.rows.forEach((row, index) => {
    drawAisle(result.aisles[index], index);
    const rackWidth = row.nominalLength / maxLength * width;
    const rowHeight = rowHeights[index];
    const selected = row.id === selectedId;
    const rowValid = row.sections.every(section => section.length);
    add(svg, 'rect', {x:x0,y,width:rackWidth,height:rowHeight,fill:rowValid?(selected?'#d8e6d9':'#e5ece5'):'#f8e9e4',stroke:rowValid?(selected?'#5b8b68':'#8fa89a'):'#bf806b','stroke-width':selected?2:1});
    if (row.type === 'double') {
      add(svg, 'line', {x1:x0+3,y1:y+rowHeight/2,x2:x0+rackWidth-3,y2:y+rowHeight/2,stroke:'#9bb5a0','stroke-width':1,'stroke-dasharray':'5 4'});
      add(svg, 'text', {x:x0+rackWidth/2,y:y+rowHeight/2+4,'text-anchor':'middle',fill:'#668a70','font-size':12,'font-family':'DM Sans','font-weight':700}, 'REGAŁ PODWÓJNY · 2 STRONY');
    } else add(svg, 'text', {x:x0+rackWidth/2,y:y+rowHeight/2+4,'text-anchor':'middle',fill:'#668a70','font-size':12,'font-family':'DM Sans','font-weight':700}, 'REGAŁ POJEDYNCZY');
    let sectionX = x0;
    const postXs = [x0+3];
    row.sections.forEach((section, sectionIndex) => {
      const fraction = ((section.length ?? section.needed) + 100) / row.nominalLength;
      const sectionWidth = fraction * rackWidth;
      add(svg, 'line', {x1:sectionX+2,y1:y+5,x2:sectionX+2,y2:y+rowHeight-5,stroke:COLORS.post,'stroke-width':3,class:'post-plan'});
      if (section.length) {
        add(svg, 'line', {x1:sectionX+5,y1:y+7,x2:sectionX+sectionWidth-2,y2:y+7,stroke:COLORS.beam,'stroke-width':3,class:'beam-plan'});
        add(svg, 'line', {x1:sectionX+5,y1:y+rowHeight-7,x2:sectionX+sectionWidth-2,y2:y+rowHeight-7,stroke:COLORS.beam,'stroke-width':3,class:'beam-plan'});
      } else add(svg, 'line', {x1:sectionX+5,y1:y+7,x2:sectionX+sectionWidth-2,y2:y+7,stroke:'#bc775e','stroke-width':3,'stroke-dasharray':'6 4'});
      sectionX += sectionWidth;
      if (sectionIndex < row.sections.length-1) postXs.push(sectionX+2);
    });
    if (config.rearProtection !== 'none') {
      const rearLines = row.type === 'double' ? [y+rowHeight/2-4,y+rowHeight/2+4] : [y+rowHeight-4];
      rearLines.forEach(rearY => add(svg, 'line', {x1:x0+5,y1:rearY,x2:x0+rackWidth-5,y2:rearY,stroke:config.rearProtection==='mesh'?'#4b9d9b':'#a66b3a','stroke-width':config.rearProtection==='mesh'?3:4,'stroke-dasharray':config.rearProtection==='mesh'?'2 2':'12 7',class:'rear-plan-line'}));
    }
    add(svg, 'line', {x1:x0+rackWidth-2,y1:y+5,x2:x0+rackWidth-2,y2:y+rowHeight-5,stroke:COLORS.post,'stroke-width':3,class:'post-plan'});
    if (config.protection === 'barrier') {
      const guardYs = row.type === 'double' ? [y+2,y+rowHeight-2] : [y+2];
      guardYs.forEach(guardY => add(svg,'line',{x1:x0+5,y1:guardY,x2:x0+rackWidth-5,y2:guardY,stroke:COLORS.guard,'stroke-width':3,class:'barrier-plan'}));
    }
    if (config.protection?.startsWith('polymer-')) {
      postXs.push(x0+rackWidth-2);
      const guardYs = row.type === 'double' ? [y+7,y+rowHeight-7] : [y+7];
      postXs.forEach(postX => guardYs.forEach(guardY => add(svg, 'circle', {cx:postX,cy:guardY,r:5.5,fill:COLORS.guardLight,'fill-opacity':.92,stroke:COLORS.guard,'stroke-width':1.5,class:'post-guard-plan'})));
    }
    add(svg, 'text', {x:9,y:y+rowHeight/2+4,fill:'#38554e','font-size':13,'font-family':'Space Grotesk','font-weight':700}, `R${String(index+1).padStart(2,'0')}`);
    add(svg, 'text', {x:583,y:y+rowHeight/2+4,fill:'#647e72','font-size':11,'font-family':'Space Grotesk','font-weight':700}, `${Math.round(row.depth)} mm`);
    const hit = add(svg, 'rect', {x:x0,y,width:rackWidth,height:rowHeight,fill:'transparent',class:'plan-hit',tabindex:0,role:'button','aria-label':`Pokaż widok frontowy regału ${index+1}`});
    hit.addEventListener('click', () => onSelect(row.id));
    hit.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onSelect(row.id); } });
    const handleX = x0 + rackWidth + 19, handleY = y + rowHeight/2;
    const handle = add(svg, 'g', {class:'plan-add',tabindex:0,role:'button','aria-label':`Dodaj sekcję do regału ${index+1}; przeciągnij lub kliknij`});
    handle.append(element('rect',{x:handleX-15,y:handleY-16,width:37,height:32,rx:5,fill:'#e7f1e8',stroke:'#79a185','stroke-dasharray':'4 3'}));
    handle.append(element('text',{x:handleX+3,y:handleY+6,'text-anchor':'middle',fill:'#437655','font-size':21,'font-family':'DM Sans','font-weight':700,'pointer-events':'none'},'+'));
    let startX = null;
    handle.addEventListener('pointerdown', event => { event.preventDefault(); event.stopPropagation(); startX = event.clientX; handle.setPointerCapture(event.pointerId); handle.classList.add('is-dragging'); });
    handle.addEventListener('pointermove', event => { if (startX === null) return; handle.setAttribute('transform', `translate(${Math.max(0,event.clientX-startX)},0)`); });
    handle.addEventListener('pointerup', event => { if (startX === null) return; event.stopPropagation(); startX = null; onAddSection(row.id); });
    handle.addEventListener('pointercancel', () => { startX = null; handle.removeAttribute('transform'); handle.classList.remove('is-dragging'); });
    handle.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); onAddSection(row.id); } });
    y += rowHeight;
  });
  if (result.aisles.length > result.rows.length) drawAisle(result.aisles.at(-1), result.aisles.length-1);
  add(svg, 'text', {x:x0,y:y+24,fill:'#5f7770','font-size':12,'font-family':'DM Sans','font-weight':700}, `GŁĘBOKOŚĆ UKŁADU Z KORYTARZAMI: ${Math.round(result.overallDepth)} mm`);
  add(svg, 'text', {x:x0,y:y+42,fill:'#98a8a2','font-size':10,'font-family':'DM Sans'}, 'Przeciągnij + przy regale, aby dodać sekcję. Kliknij rząd: widok frontowy.');
}

function drawThreeD(svg, config, result, angle, onAddSection) {
  svg.replaceChildren();
  svg.setAttribute('viewBox', '0 0 500 360');
  svg.setAttribute('aria-label', `Obracany widok 3D ${result.rows.length} regałów i korytarzy pracy`);
  const maxLength = Math.max(1, ...result.rows.map(row => row.nominalLength));
  const maxDepth = Math.max(result.overallDepth, 1);
  const raw = (x,y,z) => [x*Math.cos(angle)-y*Math.sin(angle), (x*Math.sin(angle)+y*Math.cos(angle))*.26-z*.75];
  const bounds = [];
  [0,maxLength].forEach(x => [0,maxDepth].forEach(y => [0,result.rackHeight].forEach(z => bounds.push(raw(x,y,z)))));
  const minX = Math.min(...bounds.map(p=>p[0])), maxX = Math.max(...bounds.map(p=>p[0]));
  const minY = Math.min(...bounds.map(p=>p[1])), maxY = Math.max(...bounds.map(p=>p[1]));
  const scale = Math.min(455/Math.max(1,maxX-minX),300/Math.max(1,maxY-minY));
  const offsetX = 250-(minX+maxX)*scale/2, offsetY = 190-(minY+maxY)*scale/2;
  const project = (x,y,z) => { const p=raw(x,y,z); return [p[0]*scale+offsetX,p[1]*scale+offsetY]; };
  const polygon = (coords, attrs) => add(svg,'path',{d:path(coords.map(p=>project(...p))),...attrs});
  const line = (a,b,attrs) => {const p=project(...a),q=project(...b);add(svg,'line',{x1:p[0],y1:p[1],x2:q[0],y2:q[1],...attrs});};
  const box = (x1,y1,z1,x2,y2,z2,colors) => {
    const xFace = Math.sin(angle)>0 ? x2 : x1;
    const yFace = Math.cos(angle)>0 ? y2 : y1;
    const extra = colors.class ? {class:colors.class} : {};
    polygon([[xFace,y1,z1],[xFace,y2,z1],[xFace,y2,z2],[xFace,y1,z2]],{fill:colors.side,stroke:colors.stroke,'stroke-width':.7,...extra});
    polygon([[x1,yFace,z1],[x2,yFace,z1],[x2,yFace,z2],[x1,yFace,z2]],{fill:colors.front,stroke:colors.stroke,'stroke-width':.7,...extra});
    polygon([[x1,y1,z2],[x2,y1,z2],[x2,y2,z2],[x1,y2,z2]],{fill:colors.top,stroke:colors.stroke,'stroke-width':.7,...extra});
  };
  // Ground planes identify the complete work area before the racks are rendered.
  result.aisles.forEach(aisle => {
    polygon([[0,aisle.start,0],[maxLength,aisle.start,0],[maxLength,aisle.end,0],[0,aisle.end,0]],{fill:'#e2eeeb',stroke:'#abc9c1','stroke-width':1});
    const p=project(maxLength*.45,(aisle.start+aisle.end)/2,0);
    add(svg,'text',{x:p[0],y:p[1],'text-anchor':'middle',fill:'#539282','font-size':10,'font-family':'Space Grotesk','font-weight':700},`KORYTARZ ${Math.round(result.aisle)} mm`);
  });
  const order = [...result.layoutRows].sort((a,b)=>project(a.nominalLength/2,a.start+a.depth/2,0)[1]-project(b.nominalLength/2,b.start+b.depth/2,0)[1]);
  order.forEach(row => {
    const length = row.nominalLength, y1=row.start, y2=row.end;
    const rowValid = row.sections.every(section => section.length);
    polygon([[0,y1,0],[length,y1,0],[length,y2,0],[0,y2,0]],{fill:'#edf1ed',stroke:'#b7c7ba','stroke-width':1});
    const sectionStarts=[0];
    row.sections.forEach(section => sectionStarts.push(sectionStarts.at(-1)+(section.length??section.needed)+100));
    result.levelsData.forEach(level => {
      const z=level.beamElevation;
      polygon([[0,y1,z],[length,y1,z],[length,y2,z],[0,y2,z]],{fill:'#dde9df','fill-opacity':.35,stroke:'#d2ded3','stroke-width':.5});
      line([0,y1,z],[length,y1,z],{stroke:rowValid?COLORS.beam:'#ba7459','stroke-width':2.6,class:'beam-3d',...(rowValid?{}:{'stroke-dasharray':'7 5'})});
      line([0,y2,z],[length,y2,z],{stroke:rowValid?COLORS.beam:'#ba7459','stroke-width':2.6,class:'beam-3d',...(rowValid?{}:{'stroke-dasharray':'7 5'})});
      if(row.type==='double') line([0,y1+config.palletDepth+100,z],[length,y1+config.palletDepth+100,z],{stroke:'#bdcaaf','stroke-width':1,'stroke-dasharray':'4 4'});
      const loadZ = z + 150;
      let cursor=100;
      row.sections.forEach(section => {
        const sectionLength=section.length??section.needed;
        if(section.length){
          const gap=section.clearance;
          for(let p=0;p<section.positions;p++){
            const lx=cursor+gap+p*(config.palletWidth+gap);
            const loadW=config.palletWidth*.78;
            if(lx+loadW>cursor+sectionLength)continue;
            const lanes=row.type==='double' ? [y1+config.palletDepth*.15,y2-config.palletDepth*.75] : [y1+config.palletDepth*.15];
            lanes.forEach(ly=>box(lx,ly,loadZ,lx+loadW,ly+config.palletDepth*.6,loadZ+level.loadHeight,{top:'#c3d4c4',front:'#a8c0ac',side:'#8faa98',stroke:'#6f9a7c'}));
          }
        }
        cursor+=sectionLength+100;
      });
    });
    if (config.rearProtection !== 'none') {
      const rearPlanes = row.type === 'double' ? [y1+config.palletDepth,y2-config.palletDepth] : [y2];
      rearPlanes.forEach(rearY => {
        if (config.rearProtection === 'mesh') {
          polygon([[0,rearY,0],[length,rearY,0],[length,rearY,result.rackHeight],[0,rearY,result.rackHeight]],{fill:'#94ceca','fill-opacity':.2,stroke:'#4b9d9b','stroke-width':1,class:'rear-mesh-panel'});
          for (let x=450; x<length; x+=450) line([x,rearY,0],[x,rearY,result.rackHeight],{stroke:'#4b9d9b','stroke-width':.55,'stroke-opacity':.6});
          for (let z=500; z<result.rackHeight; z+=500) line([0,rearY,z],[length,rearY,z],{stroke:'#4b9d9b','stroke-width':.55,'stroke-opacity':.6});
        } else {
          result.levelsData.forEach(level => {
            const stopZ = level.beamElevation + 150 + Math.min(300, level.loadHeight*.2);
            line([0,rearY,stopZ],[length,rearY,stopZ],{stroke:'#a66b3a','stroke-width':3.5,class:'rear-backstop-rail'});
            sectionStarts.forEach(x => line([Math.min(x,length),rearY,stopZ-85],[Math.min(x,length),rearY,stopZ+85],{stroke:'#a66b3a','stroke-width':1.8}));
          });
        }
      });
    }
    const frameXs = [...sectionStarts.slice(0,-1),length];
    frameXs.forEach(x => {
      [y1,y2].forEach(y => line([x,y,0],[x,y,result.rackHeight],{stroke:COLORS.post,'stroke-width':3.2,class:'post-3d'}));
      for (let z=350, side=0; z<result.rackHeight-250; z+=1100,side++) {
        const nextZ=Math.min(z+1100,result.rackHeight-250);
        line([x,side%2?y2:y1,z],[x,side%2?y1:y2,nextZ],{stroke:COLORS.galva,'stroke-width':1.8,class:'frame-diagonal-3d'});
      }
    });
    if (config.protection === 'barrier') {
      const guardYs = row.type === 'double' ? [y1,y2] : [y1];
      guardYs.forEach(y => line([0,y,260],[length,y,260],{stroke:COLORS.guard,'stroke-width':4,class:'barrier-3d'}));
    }
    if (config.protection?.startsWith('polymer-')) {
      const guardXs = [...sectionStarts.slice(0,-1),length];
      const guardYs = row.type === 'double' ? [y1,y2] : [y1];
      guardXs.forEach(x => guardYs.forEach(y => {
        const near = y === y1 ? y : y-95;
        box(Math.max(0,x-85),near,0,Math.min(length,x+85),near+95,Math.min(650,result.rackHeight*.13),{top:COLORS.guardLight,front:COLORS.guard,side:'#c79400',stroke:'#8e7100',class:'post-guard-3d'});
      }));
    }
    line([0,y1,result.rackHeight],[length,y1,result.rackHeight],{stroke:COLORS.post,'stroke-width':2});
    line([0,y2,result.rackHeight],[length,y2,result.rackHeight],{stroke:COLORS.post,'stroke-width':2});
    const label=project(length/2,(y1+y2)/2,result.rackHeight+300);
    add(svg,'text',{x:label[0],y:label[1],'text-anchor':'middle',fill:rowValid?'#3a5b54':'#a5634c','font-size':10,'font-family':'Space Grotesk','font-weight':700},`R${String(result.rows.findIndex(r=>r.id===row.id)+1).padStart(2,'0')}${rowValid?(row.type==='double'?' · PODWÓJNY':''):' · BRAK DOBORU'}`);
  });
  result.layoutRows.forEach((row, index) => {
    const anchor=project(row.nominalLength,row.start+row.depth/2,result.rackHeight*.55);
    const cx=Math.max(24,Math.min(476,anchor[0]+15)),cy=Math.max(45,Math.min(320,anchor[1]));
    const control=add(svg,'g',{class:'threeD-add',role:'button',tabindex:0,'aria-label':`Dodaj sekcję do regału ${index+1}`});
    control.append(element('circle',{cx,cy,r:16,fill:'#d8f0dc','fill-opacity':.72,stroke:'#4e9461','stroke-width':1.5}));
    control.append(element('text',{x:cx,y:cy+6,'text-anchor':'middle',fill:'#2c7142','font-size':23,'font-family':'DM Sans','font-weight':700,'pointer-events':'none'},'+'));
    control.addEventListener('pointerdown',event=>event.stopPropagation());
    control.addEventListener('click',event=>{event.stopPropagation();onAddSection(row.id);});
    control.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();onAddSection(row.id);}});
  });
  add(svg,'text',{x:15,y:27,fill:'#49625f','font-size':12,'font-family':'DM Sans','font-weight':700},'MODEL 3D / WSZYSTKIE REGAŁY');
  add(svg,'text',{x:485,y:27,'text-anchor':'end',fill:'#81938e','font-size':10,'font-family':'DM Sans'},'KLIKNIJ + PRZY REGALE');
  add(svg,'text',{x:15,y:344,fill:'#98a8a2','font-size':9,'font-family':'DM Sans'},'Model poglądowy: rozstaw i wysokość według konfiguracji.');
}

root.RackformVisuals = { COLORS, drawPlan, drawThreeD };
})(globalThis);
